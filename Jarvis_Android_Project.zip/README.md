# JARVIS (Android voice assistant) by SINGH DEVELOPER

## Step 1: GitHub pe daalo
Poora folder ek repo me push karo (branch: main).

## Step 2: Backend (Vercel)
1. vercel.com -> Add New Project -> apni GitHub repo chuno.
2. **Root Directory = `backend`** set karo.
3. Environment Variables: `ANTHROPIC_API_KEY` (apni Claude API key), `APP_KEY` (koi bhi lamba secret).
4. Deploy. URL banega: https://<project>.vercel.app/api/jarvis

## Step 3: GitHub Secrets
Repo -> Settings -> Secrets and variables -> Actions -> New secret:
- `BACKEND_URL` = upar wala poora URL (…/api/jarvis)
- `APP_KEY` = wahi secret jo Vercel me dala

## Step 4: APK
Actions tab -> "Build Jarvis APK" -> Run workflow (ya push pe khud chalega).
5-8 min baad run ke andar **Artifacts -> Jarvis-APK** se app-debug.apk download karo, phone me install karo.

## Commands examples
- "Mummy ko call karo"
- "Rahul ko SMS bhejo ki main late aaunga"
- "Rahul ko WhatsApp karo ki kal milte hain"
- "YouTube kholo", "torch on karo", "kal subah 7 baje ka alarm lagao"
