package com.singhdeveloper.jarvis

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Brain {
    fun ask(text: String, history: JSONArray): JSONObject {
        return try {
            val c = URL(BuildConfig.BACKEND_URL).openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 40000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-app-key", BuildConfig.APP_KEY)
            val payload = JSONObject().put("text", text).put("history", history)
            c.outputStream.use { it.write(payload.toString().toByteArray()) }
            val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
            val body = stream.bufferedReader().readText()
            val j = JSONObject(body)
            if (!j.has("speech")) j.put("speech", "Server me kuch problem hai").put("action", "none")
            j
        } catch (e: Exception) {
            JSONObject().put("speech", "Internet ya server check karo").put("action", "none")
        }
    }
}
