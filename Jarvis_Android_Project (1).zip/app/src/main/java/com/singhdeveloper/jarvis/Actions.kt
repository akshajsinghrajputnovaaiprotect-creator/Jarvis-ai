package com.singhdeveloper.jarvis

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import org.json.JSONObject

object Actions {

    /** Returns null on success, or an error message to speak. */
    fun run(ctx: Context, action: String, a: JSONObject): String? {
        return try {
            when (action) {
                "call" -> call(ctx, a.optString("contact"))
                "sms" -> sms(ctx, a.optString("contact"), a.optString("text"))
                "whatsapp" -> whatsapp(ctx, a.optString("contact"), a.optString("text"))
                "open_app" -> openApp(ctx, a.optString("app"))
                "flashlight" -> flashlight(ctx, a.optBoolean("on", true))
                "alarm" -> alarm(ctx, a.optInt("hour"), a.optInt("minute"), a.optString("label", "Jarvis"))
                "timer" -> timer(ctx, a.optInt("seconds", 60))
                "search" -> view(ctx, Intent(Intent.ACTION_WEB_SEARCH).putExtra("query", a.optString("query")))
                "navigate" -> view(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(a.optString("place")))))
                "busy_mode" -> { CallStore.setBusy(ctx, a.optBoolean("on", true)); null }
                "play" -> view(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(a.optString("query")))))
                else -> null
            }
        } catch (e: Exception) {
            "Kuch gadbad ho gayi: ${e.message}"
        }
    }

    private fun view(ctx: Context, i: Intent): String? {
        ctx.startActivity(i); return null
    }

    private fun number(ctx: Context, name: String): String? {
        val digits = name.filter { it.isDigit() || it == '+' }
        if (digits.count { it.isDigit() } >= 7) return digits
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        ctx.contentResolver.query(
            Phone.CONTENT_URI, arrayOf(Phone.NUMBER),
            "${Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null
        )?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }

    private fun call(ctx: Context, name: String): String? {
        val n = number(ctx, name) ?: return "$name ka number nahi mila"
        ctx.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(n))))
        return null
    }

    private fun sms(ctx: Context, name: String, text: String): String? {
        val n = number(ctx, name) ?: return "$name ka number nahi mila"
        val sm = ctx.getSystemService(SmsManager::class.java)
        sm.sendMultipartTextMessage(n, null, sm.divideMessage(text), null, null)
        return null
    }

    private fun whatsapp(ctx: Context, name: String, text: String): String? {
        var n = number(ctx, name)?.filter { it.isDigit() } ?: return "$name ka number nahi mila"
        if (n.length == 10) n = "91$n"
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$n?text=" + Uri.encode(text)))
        i.setPackage("com.whatsapp")
        ctx.startActivity(i) // Send button khud dabana padega
        return null
    }

    private fun openApp(ctx: Context, name: String): String? {
        val pm = ctx.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val m = pm.queryIntentActivities(q, 0)
            .firstOrNull { it.loadLabel(pm).toString().contains(name, true) }
            ?: return "$name app nahi mila"
        ctx.startActivity(pm.getLaunchIntentForPackage(m.activityInfo.packageName))
        return null
    }

    private fun flashlight(ctx: Context, on: Boolean): String? {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        cm.setTorchMode(cm.cameraIdList.first(), on)
        return null
    }

    private fun alarm(ctx: Context, h: Int, m: Int, label: String): String? {
        ctx.startActivity(
            Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, h)
                .putExtra(AlarmClock.EXTRA_MINUTES, m)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        return null
    }

    private fun timer(ctx: Context, sec: Int): String? {
        ctx.startActivity(
            Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, sec)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        return null
    }
}
