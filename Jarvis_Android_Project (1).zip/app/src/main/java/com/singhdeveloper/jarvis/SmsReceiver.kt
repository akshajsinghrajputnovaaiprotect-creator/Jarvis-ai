package com.singhdeveloper.jarvis

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

/** Busy mode me jis number ko Jarvis ne SMS bheja, uska reply yahan aata hai. */
class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        val from = msgs.firstOrNull()?.originatingAddress ?: return
        val body = msgs.joinToString("") { it.messageBody ?: "" }

        val idx = CallStore.recentIndex(ctx, from, 24 * 3600_000L, "busy_auto_reply")
        if (idx < 0) return

        val pending = goAsync()
        Thread {
            try { handle(ctx, idx, from, body) } catch (e: Exception) { /* ignore */ }
            finally { pending.finish() }
        }.start()
    }

    private fun handle(ctx: Context, idx: Int, from: String, body: String) {
        CallStore.addMessage(ctx, idx, "caller", body)
        val entry = CallStore.get(ctx, idx)
        if (entry.optBoolean("done") || entry.optInt("replies") >= 4) return

        val r = Brain.screen(entry.getJSONArray("messages"), 8000) ?: return
        val reply = r.optString("reply").trim()
        if (reply.isNotEmpty()) {
            SmsOut.send(ctx, from, reply)
            CallStore.addMessage(ctx, idx, "jarvis", reply)
        }
        val cname = r.optString("name")
        val purpose = r.optString("purpose")
        if (cname.isNotBlank()) CallStore.setField(ctx, idx, "caller_name", cname)
        if (purpose.isNotBlank()) CallStore.setField(ctx, idx, "purpose", purpose)
        CallStore.setField(ctx, idx, "urgent", r.optBoolean("urgent"))

        if (r.optBoolean("done")) {
            CallStore.setField(ctx, idx, "done", true)
            val who = cname.ifBlank { entry.optString("name").ifBlank { from } }
            Notifier.show(
                ctx,
                if (r.optBoolean("urgent")) "URGENT: $who ne call kiya tha" else "$who ne call kiya tha",
                purpose.ifBlank { "Kaam nahi bataya" }
            )
        }
    }
}
