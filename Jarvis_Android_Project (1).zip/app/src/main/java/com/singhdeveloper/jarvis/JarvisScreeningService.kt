package com.singhdeveloper.jarvis

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.telecom.Call
import android.telecom.CallScreeningService
import androidx.core.content.ContextCompat

class JarvisScreeningService : CallScreeningService() {

    private val allow get() = CallResponse.Builder().build()

    override fun onScreenCall(details: Call.Details) {
        val incoming = Build.VERSION.SDK_INT < 29 ||
            details.callDirection == Call.Details.DIRECTION_INCOMING
        if (!incoming) { respondToCall(details, allow); return }

        val number = details.handle?.schemeSpecificPart ?: ""
        val hasContactsPerm = ContextCompat.checkSelfPermission(
            this, Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED
        val name = if (hasContactsPerm) contactName(number) else ""

        // 1) Busy mode: Jarvis sab calls sambhalta hai
        if (CallStore.isBusy(this)) {
            val repeated = number.isNotEmpty() && CallStore.recentIndex(this, number, 3 * 60_000L) >= 0
            if (repeated) {
                // 3 minute me dobara call = urgent ho sakta hai, ring hone do
                Notifier.show(this, "Dobara call aaya", name.ifEmpty { number })
                respondToCall(details, allow)
            } else {
                handleBusy(details, number, name)
            }
            return
        }

        // 2) Normal mode: unknown number ki jaanch, phir call tumhe ring hota hai
        if (hasContactsPerm && name.isEmpty() && number.isNotEmpty()) {
            if (isTelemarketer(number)) {
                CallStore.add(this, number, "", "spam_blocked")
                respondToCall(
                    details,
                    CallResponse.Builder()
                        .setDisallowCall(true).setRejectCall(true).setSkipNotification(true).build()
                )
                return
            }
            CallStore.add(this, number, "", "unknown_allowed")
            Notifier.show(this, "Unknown number se call", number)
        }
        respondToCall(details, allow)
    }

    private fun handleBusy(details: Call.Details, number: String, name: String) {
        val idx = CallStore.add(this, number, name, "busy_auto_reply")
        respondToCall(details, CallResponse.Builder().setDisallowCall(true).setRejectCall(true).build())

        if (number.filter { it.isDigit() }.length >= 10) {
            val msg = "Namaste! Main Jarvis hoon, is number ke owner ka AI assistant. " +
                "Wo abhi busy hain. Aap apna naam aur call ka kaam is message ka reply karke bata dein, " +
                "main unhe pahuncha dunga."
            Thread {
                try {
                    SmsOut.send(this, number, msg)
                    CallStore.addMessage(this, idx, "jarvis", msg)
                } catch (e: Exception) { /* SMS permission ya network issue */ }
            }.start()
        }
        Notifier.show(this, "Busy mode: call sambhala", name.ifEmpty { number.ifEmpty { "Private number" } })
    }

    private fun contactName(number: String): String {
        if (number.isEmpty()) return ""
        return try {
            val uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)
            )
            contentResolver.query(
                uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
            )?.use { if (it.moveToFirst()) it.getString(0) ?: "" else "" } ?: ""
        } catch (e: Exception) { "" }
    }

    /** Simple filter: India ke 140 series (promotional/telemarketing) numbers. */
    private fun isTelemarketer(number: String): Boolean {
        var d = number.filter { it.isDigit() }
        if (d.length == 12 && d.startsWith("91")) d = d.substring(2)
        return d.startsWith("140")
    }
}
