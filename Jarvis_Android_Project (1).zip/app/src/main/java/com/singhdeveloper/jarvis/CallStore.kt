package com.singhdeveloper.jarvis

import android.content.Context
import android.telephony.SmsManager
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object SmsOut {
    fun send(ctx: Context, number: String, text: String) {
        val sm = ctx.getSystemService(SmsManager::class.java)
        sm.sendMultipartTextMessage(number, null, sm.divideMessage(text), null, null)
    }
}

/** Busy-mode flag + log of handled calls (stored on phone only). */
object CallStore {
    private const val PREFS = "jarvis_store"
    private fun sp(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun isBusy(ctx: Context) = sp(ctx).getBoolean("busy", false)
    fun setBusy(ctx: Context, on: Boolean) { sp(ctx).edit().putBoolean("busy", on).apply() }

    @Synchronized
    fun all(ctx: Context): JSONArray =
        try { JSONArray(sp(ctx).getString("calls", "[]")) } catch (e: Exception) { JSONArray() }

    @Synchronized
    private fun save(ctx: Context, a: JSONArray) {
        while (a.length() > 100) a.remove(0)
        sp(ctx).edit().putString("calls", a.toString()).apply()
    }

    fun same(a: String, b: String): Boolean {
        val x = a.filter { it.isDigit() }.takeLast(10)
        val y = b.filter { it.isDigit() }.takeLast(10)
        return x.isNotEmpty() && x == y
    }

    /** status: busy_auto_reply | spam_blocked | unknown_allowed. Returns index. */
    @Synchronized
    fun add(ctx: Context, number: String, name: String, status: String): Int {
        val a = all(ctx)
        a.put(
            JSONObject().put("number", number).put("name", name)
                .put("time", System.currentTimeMillis()).put("status", status)
                .put("messages", JSONArray()).put("replies", 0)
                .put("done", false).put("reported", false)
        )
        save(ctx, a)
        return a.length() - 1
    }

    @Synchronized
    fun recentIndex(ctx: Context, number: String, withinMs: Long, status: String? = null): Int {
        val a = all(ctx)
        val now = System.currentTimeMillis()
        for (i in a.length() - 1 downTo 0) {
            val e = a.getJSONObject(i)
            if (same(e.optString("number"), number) &&
                now - e.optLong("time") < withinMs &&
                (status == null || e.optString("status") == status)
            ) return i
        }
        return -1
    }

    @Synchronized
    fun get(ctx: Context, idx: Int): JSONObject = all(ctx).getJSONObject(idx)

    @Synchronized
    fun addMessage(ctx: Context, idx: Int, from: String, text: String) {
        val a = all(ctx)
        val e = a.getJSONObject(idx)
        e.getJSONArray("messages").put(JSONObject().put("from", from).put("text", text))
        if (from == "jarvis") e.put("replies", e.optInt("replies") + 1)
        save(ctx, a)
    }

    @Synchronized
    fun setField(ctx: Context, idx: Int, key: String, value: Any) {
        val a = all(ctx)
        a.getJSONObject(idx).put(key, value)
        save(ctx, a)
    }

    /** Entries not yet reported to the owner, with a readable time. */
    @Synchronized
    fun unreported(ctx: Context): JSONArray {
        val out = JSONArray()
        val fmt = SimpleDateFormat("dd MMM, hh:mm a", Locale.ENGLISH)
        val a = all(ctx)
        for (i in 0 until a.length()) {
            val e = a.getJSONObject(i)
            if (e.optBoolean("reported")) continue
            out.put(
                JSONObject(e.toString()).put("when", fmt.format(Date(e.optLong("time"))))
            )
        }
        return out
    }

    @Synchronized
    fun markAllReported(ctx: Context) {
        val a = all(ctx)
        for (i in 0 until a.length()) a.getJSONObject(i).put("reported", true)
        save(ctx, a)
    }
}
