package com.singhdeveloper.jarvis

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var reply: TextView
    private lateinit var mic: Button
    private lateinit var busyBtn: Button
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val history = JSONArray()
    private var pending: Pair<String, JSONObject>? = null

    private fun perms(): Array<String> {
        val l = mutableListOf(
            Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE, Manifest.permission.SEND_SMS,
            Manifest.permission.RECEIVE_SMS
        )
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        return l.toTypedArray()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        ActivityCompat.requestPermissions(this, perms(), 1)

        tts = TextToSpeech(this) {
            tts?.language = Locale("hi", "IN")
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onError(id: String?) {}
                override fun onDone(id: String?) {
                    if (id == "listen") runOnUiThread { startListening() }
                }
            })
        }

        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { status.text = "Sun raha hoon..." }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "Samajh raha hoon..." }
            override fun onError(e: Int) { status.text = "Dobara bolo (tap karo)"; pending = null }
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onPartialResults(p: Bundle?) {
                p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { status.text = it }
            }
            override fun onResults(r: Bundle?) {
                val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                onHeard(t)
            }
        })
    }

    override fun onResume() { super.onResume(); refreshBusy() }

    private fun pill(color: String, stroke: String) = GradientDrawable().apply {
        setColor(Color.parseColor(color)); cornerRadius = 40f
        setStroke(3, Color.parseColor(stroke))
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.parseColor("#05080F"))
            setPadding(48, 120, 48, 48)
        }
        root.addView(TextView(this).apply {
            text = "J.A.R.V.I.S"; textSize = 28f; setTextColor(Color.parseColor("#00E5FF"))
            typeface = Typeface.MONOSPACE; gravity = Gravity.CENTER
        })
        status = TextView(this).apply {
            text = "Mic dabao aur bolo"; textSize = 16f; setTextColor(Color.parseColor("#8899AA"))
            gravity = Gravity.CENTER; setPadding(0, 48, 0, 24)
        }
        root.addView(status)
        reply = TextView(this).apply {
            textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        }
        root.addView(reply, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        mic = Button(this).apply {
            text = "🎤"; textSize = 40f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setColor(Color.parseColor("#0A2A3A"))
                setStroke(6, Color.parseColor("#00E5FF"))
            }
            setOnClickListener { pending = null; startListening() }
        }
        root.addView(mic, LinearLayout.LayoutParams(280, 280).apply { gravity = Gravity.CENTER_HORIZONTAL })

        val row = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, 32, 0, 0) }
        busyBtn = Button(this).apply {
            setTextColor(Color.WHITE); background = pill("#1A2433", "#00E5FF")
            setOnClickListener {
                val on = !CallStore.isBusy(this@MainActivity)
                CallStore.setBusy(this@MainActivity, on)
                refreshBusy()
                say(if (on) "Busy mode on. Ab saari calls main sambhalunga." else "Busy mode off. Report sunna chahoge to 'report batao' bolo.")
            }
        }
        row.addView(busyBtn, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { rightMargin = 12 })
        row.addView(Button(this).apply {
            text = "📞 Call report"; setTextColor(Color.WHITE); background = pill("#1A2433", "#00E5FF")
            setOnClickListener { report() }
        }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { leftMargin = 12 })
        root.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        root.addView(Button(this).apply {
            text = "🛡 Call screening on karo (ek baar)"
            setTextColor(Color.WHITE); background = pill("#1A2433", "#445566")
            setOnClickListener { enableScreening() }
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = 16 })

        root.addView(TextView(this).apply {
            text = "by SINGH DEVELOPER"; textSize = 12f
            setTextColor(Color.parseColor("#445566")); gravity = Gravity.CENTER; setPadding(0, 32, 0, 0)
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        setContentView(root)
    }

    private fun refreshBusy() {
        busyBtn.text = if (CallStore.isBusy(this)) "🔕 Busy: ON" else "🔔 Busy: OFF"
    }

    private fun enableScreening() {
        if (Build.VERSION.SDK_INT < 29) { say("Call screening ke liye Android 10 ya upar chahiye"); return }
        val rm = getSystemService(RoleManager::class.java)
        when {
            !rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) -> say("Is phone me call screening available nahi hai")
            rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING) -> say("Call screening pehle se on hai")
            else -> startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING), 55)
        }
    }

    private fun report() {
        val calls = CallStore.unreported(this)
        if (calls.length() == 0) { say("Koi naya call record nahi hai"); return }
        status.text = "Report bana raha hoon..."
        thread {
            val text = Brain.report(calls)
            runOnUiThread {
                if (text == null) say("Report nahi ban payi, internet check karo")
                else { CallStore.markAllReported(this); say(text) }
            }
        }
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            status.text = "Mic permission do"; return
        }
        tts?.stop()
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        recognizer?.startListening(i)
    }

    private fun onHeard(text: String) {
        status.text = "\"$text\""
        val p = pending
        if (p != null) {            // confirmation answer
            pending = null
            val yes = Regex("(haan|han|ha |yes|kar do|bhej do|laga do|theek|ok|sure)", RegexOption.IGNORE_CASE)
            if (yes.containsMatchIn("$text ") || text.contains("हाँ") || text.contains("हां") || text.contains("कर दो")) {
                val err = Actions.run(this, p.first, p.second)
                say(err ?: "Ho gaya")
            } else say("Theek hai, cancel kar diya")
            return
        }
        status.text = "Soch raha hoon..."
        thread {
            val resp = Brain.ask(text, history)
            runOnUiThread { handle(text, resp) }
        }
    }

    private fun handle(userText: String, resp: JSONObject) {
        val speech = resp.optString("speech")
        val action = resp.optString("action", "none")
        val args = resp.optJSONObject("args") ?: JSONObject()

        history.put(JSONObject().put("role", "user").put("content", userText))
        history.put(JSONObject().put("role", "assistant").put("content", resp.toString()))
        while (history.length() > 12) history.remove(0)

        when (action) {
            "call", "sms" -> { pending = action to args; say(speech, listenAfter = true) }
            "call_report" -> report()
            else -> {
                val err = if (action != "none") Actions.run(this, action, args) else null
                refreshBusy()
                say(err ?: speech)
            }
        }
    }

    private fun say(text: String, listenAfter: Boolean = false) {
        reply.text = text
        status.text = if (listenAfter) "Haan ya na bolo..." else "Mic dabao aur bolo"
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, if (listenAfter) "listen" else "done")
    }

    override fun onDestroy() {
        recognizer?.destroy(); tts?.shutdown(); super.onDestroy()
    }
}
