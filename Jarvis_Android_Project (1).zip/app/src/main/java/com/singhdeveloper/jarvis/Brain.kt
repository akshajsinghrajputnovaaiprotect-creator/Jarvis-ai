package com.singhdeveloper.jarvis

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Brain {

    private fun post(payload: JSONObject, readTimeoutMs: Int = 40000): JSONObject {
        val c = URL(BuildConfig.BACKEND_URL).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 8000
        c.readTimeout = readTimeoutMs
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-app-key", BuildConfig.APP_KEY)
        c.outputStream.use { it.write(payload.toString().toByteArray()) }
        val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
        return JSONObject(stream.bufferedReader().readText())
    }

    /** Voice commands: returns {speech, action, args} */
    fun ask(text: String, history: JSONArray): JSONObject {
        return try {
            val j = post(JSONObject().put("text", text).put("history", history))
            if (!j.has("speech")) j.put("speech", "Server me kuch problem hai").put("action", "none")
            j
        } catch (e: Exception) {
            JSONObject().put("speech", "Internet ya server check karo").put("action", "none")
        }
    }

    /** Busy mode: caller se SMS baat-cheet. Returns {reply, done, name, purpose, urgent} or null */
    fun screen(messages: JSONArray, timeoutMs: Int): JSONObject? {
        return try {
            val j = post(JSONObject().put("mode", "screen").put("messages", messages), timeoutMs)
            if (j.has("reply")) j else null
        } catch (e: Exception) { null }
    }

    /** Call report ka bola jaane wala summary. Returns null on failure. */
    fun report(calls: JSONArray): String? {
        return try {
            val j = post(JSONObject().put("mode", "report").put("calls", calls), 40000)
            j.optString("text").ifBlank { null }
        } catch (e: Exception) { null }
    }
}
