plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.singhdeveloper.jarvis"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.singhdeveloper.jarvis"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        // GitHub Secrets (BACKEND_URL, APP_KEY) se aate hain; local build me yahi defaults
        val backendUrl = System.getenv("BACKEND_URL")?.takeIf { it.isNotBlank() }
            ?: "https://YOUR-APP.vercel.app/api/jarvis"
        val appKey = System.getenv("APP_KEY")?.takeIf { it.isNotBlank() }
            ?: "CHANGE_ME_SECRET"
        buildConfigField("String", "BACKEND_URL", "\"$backendUrl\"")
        buildConfigField("String", "APP_KEY", "\"$appKey\"")
    }
    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
}
