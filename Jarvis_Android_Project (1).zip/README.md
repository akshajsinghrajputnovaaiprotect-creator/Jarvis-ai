# JARVIS (Android voice assistant) by SINGH DEVELOPER

Features: voice commands (call, SMS, WhatsApp, apps, alarm...), unknown-call check,
Busy mode (Jarvis rejects calls, SMS karke naam aur kaam puchta hai, baad me report deta hai).

## Setup
1. `backend/` Vercel pe deploy (Root Directory = backend). Env vars: `GEMINI_API_KEY`, `APP_KEY`.
2. GitHub Secrets: `BACKEND_URL` (.../api/jarvis), `APP_KEY`.
3. Actions -> Build Jarvis APK -> APK download -> install.
4. App kholke saari permissions Allow karo, phir "Call screening on karo" dabao aur Jarvis ko chuno.

## Phone settings (zaroori)
- App info -> 3 dots -> "Allow restricted settings" (agar dikhe)
- Battery -> No restrictions, Autostart ON (Xiaomi/Realme/Oppo/Vivo)
- Notifications ON

## Voice examples
- "Main abhi busy hoon, koi bhi call aaye to tum sambhalo"
- "Ab free hoon" / "Report batao" / "Kisne call kiya tha?"
- "Mummy ko call karo", "Rahul ko SMS bhejo ki ..."
